# WORKNADET — Digital Intelligence

Static website for publishing with GitHub Pages.

## Publish the site

1. Create a new repository on GitHub.
2. Upload `index.html` and `README.md` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The public URL will appear in the Pages section.

The website is packaged as a single HTML file and its image assets are embedded in that file, so no separate CSS, JavaScript, or image files are required for the current version.
